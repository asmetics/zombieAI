package asmetics.zombieai

import net.fabricmc.api.ModInitializer
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerBlockEntityEvents
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry
import net.minecraft.world.GameRules
import net.minecraft.world.GameRules.BooleanRule
import net.minecraft.world.GameRules.Category
import net.minecraft.block.entity.BlockEntity
import net.minecraft.server.world.ServerWorld
import net.minecraft.util.math.BlockPos
import org.slf4j.LoggerFactory


object spawning : ModInitializer { private val logger = LoggerFactory.getLogger("zombieai")
	override fun onInitialize() {
		val DO_APOCALYPSE: GameRules.Key<BooleanRule> = GameRuleRegistry.register("doApocalypse", Category.MOBS, GameRuleFactory.createBooleanRule(true))
		val DO_SPRINTERS: GameRules.Key<BooleanRule> = GameRuleRegistry.register("doSprinters", Category.MOBS, GameRuleFactory.createBooleanRule(true))
	}

	

}

